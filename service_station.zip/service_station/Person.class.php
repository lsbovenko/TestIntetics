<?php
class Person{
    public $connection;
    public $values;

    public function __construct($connection){
        $this->connection = $connection;
    }

    public function existPerson($firstName, $lastName){
        $sqlExist = "SELECT COUNT(*) FROM Persons WHERE First_name = '$firstName' AND Last_name = '$lastName'";
        $resValues = mysqli_query($this->connection, $sqlExist);
        $item = mysqli_fetch_row($resValues);
        return $item[0];
    }

    public function setPerson($firstName, $lastName, $dateOfBirth, $address, $phone, $mail){
        $sqlSet = "INSERT INTO Persons (First_name, Last_name, Date_of_birth, Address, Phone, Mail)
                   VALUES ('$firstName', '$lastName', '$dateOfBirth', '$address', '$phone', '$mail')";
        mysqli_query($this->connection, $sqlSet);
    }

    public function getPerson($firstName, $lastName){
        $sqlGet = "SELECT * FROM Persons WHERE First_name = '$firstName' AND Last_name = '$lastName'";
        $resValues = mysqli_query($this->connection, $sqlGet);
        if($item = mysqli_fetch_assoc($resValues)){
            $this->values = array('idPerson'=>$item['Id_person'],
                                  'firstName'=>$item['First_name'],
                                  'lastName'=>$item['Last_name'],
                                  'dateOfBirth'=>$item['Date_of_birth'],
                                  'address'=>$item['Address'],
                                  'phone'=>$item['Phone'],
                                  'mail'=>$item['Mail']);
        }
    }
}