<html>
<head>
</head>
<body>

<?php
function __autoload($class){
    require_once ($class.'.class.php');
}

if($_SERVER["REQUEST_METHOD"] == "GET"){
    $idAuto = $_GET["idAuto"];
    $idPerson = $_GET["idPerson"];
    $firstName = $_GET["firstName"];
    $lastName = $_GET["lastName"];
}
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $idOrder = $_POST["idOrder"];
    $idAuto = $_POST["idAuto"];
    $idPerson = $_POST["idPerson"];
    $firstName = $_POST["firstName"];
    $lastName = $_POST["lastName"];
}

$base = Base::getInstance();

$order = new Order($base->connection);

if($idOrder == true && $_POST["flOrder"] == false){
    $curValues = $order->getOrder($idOrder);
?>
    <form action="<?php $_SERVER["PHP_SELF"]?>" method="post">
        <p><b>Update information of order</b></p>
        <p><input type="text" name="orderAmount" value="<?=$curValues["orderAmount"]?>"> Order amount</p>

        <p>Select order status</p>
        <p><select size="1" name="orderStatus">
<?php
        if($curValues["orderStatus"] == 'Completed')
            echo "<option selected value='Completed'>Completed</option>";
        else
            echo "<option value='Completed'>Completed</option>";
        if($curValues["orderStatus"] == 'In Progress')
            echo "<option selected value='In Progress'>In Progress</option>";
        else
            echo "<option value='In Progress'>In Progress</option>";
        if($curValues["orderStatus"] == 'Cancelled')
            echo "<option selected value='Cancelled'>Cancelled</option>";
        else
            echo "<option value='Cancelled'>Cancelled</option>";
?>
        </select></p>

        <input type="hidden" name = "idOrder" value="<?=$idOrder?>">
        <input type="hidden" name = "idAuto" value="<?=$idAuto?>">
        <input type="hidden" name = "idPerson" value="<?=$idPerson?>">
        <input type="hidden" name = "firstName" value="<?=$firstName?>">
        <input type="hidden" name = "lastName" value="<?=$lastName?>">
        <input type="hidden" name = "flOrder" value="true">
        <p><input type="submit" value="Update info"></p><br><hr><br>
    </form>
<?php
}

if($_POST["flOrder"]){
    $orderAmount = trim(strip_tags($_POST["orderAmount"]));
    $orderStatus = $_POST["orderStatus"];

    $order->updateOrder($idOrder, $orderAmount, $orderStatus);
}

if($order->existOrder($idAuto)){
    $order->getAllOrder($idAuto);
?>
    <form action="<?php $_SERVER["PHP_SELF"]?>" method="post">
        <p><b>Select order</b></p>
        <p><select size="1" name="idOrder">
            <?php foreach($order->values as $curOrder): ?>
                <option value="<?=$curOrder['idOrder']?>"><?=$curOrder['date'] . ' ' .
                                                             $curOrder['orderAmount'] . ' ' .
                                                             $curOrder['orderStatus']?>
                </option>
            <?php endforeach; ?>
        </select></p>
        <input type="hidden" name="idAuto" value="<?=$idAuto?>">
        <input type="hidden" name="idPerson" value="<?=$idPerson?>">
        <input type="hidden" name = "firstName" value="<?=$firstName?>">
        <input type="hidden" name = "lastName" value="<?=$lastName?>">
        <p><input type="submit" value="Show info"></p>
    </form>
<?php
}
else{
    echo "No order<p></p>";
}
?>

<br><hr><br>
<form action="showAuto.php" method="post">
    <input type="hidden" name = "idAuto" value="<?=$idAuto?>">
    <input type="hidden" name = "idPerson" value="<?=$idPerson?>">
    <input type="hidden" name = "firstName" value="<?=$firstName?>">
    <input type="hidden" name = "lastName" value="<?=$lastName?>">
    <p><input type="submit" value="Back to auto"></p>
</form>

<form action="index.php" method="post">
    <input type="hidden" name = "firstName" value="<?=$firstName?>">
    <input type="hidden" name = "lastName" value="<?=$lastName?>">
    <p><input type="submit" value="Back to person"></p>
</form>

</body>
</html>