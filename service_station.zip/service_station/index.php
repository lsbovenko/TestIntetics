<html>
<head>
</head>
<body>

<?php
function __autoload($class){
    require_once ($class.'.class.php');
}

if($_SERVER["REQUEST_METHOD"] == "POST"){
    if($_POST["firstName"] != null && $_POST["lastName"] != null){
        $firstName = trim(strip_tags($_POST["firstName"]));
        $lastName = trim(strip_tags($_POST["lastName"]));

        $base = Base::getInstance();
        $base->createTables();
        $person = new Person($base->connection);

        if($_POST["flPerson"]){
            $dateOfBirth = trim(strip_tags($_POST["dateOfBirth"]));
            $address = trim(strip_tags($_POST["address"]));
            $phone = trim(strip_tags($_POST["phone"]));
            $mail = trim(strip_tags($_POST["mail"]));

            $person->setPerson($firstName, $lastName, $dateOfBirth, $address, $phone, $mail);
        }

        if(!($person->existPerson($firstName, $lastName))){
?>
            <form action="<?php $_SERVER["PHP_SELF"]?>" method="post">
                <p><b>Enter information of person</b></p>
                <p><input type="text" name="firstName" value="<?=$firstName?>"> First name</p>
                <p><input type="text" name="lastName" value="<?=$lastName?>"> Last name</p>
                <p><input type="text" name="dateOfBirth" value=""> Date of birth</p>
                <p><input type="text" name="address" value=""> Address</p>
                <p><input type="text" name="phone" value=""> Phone</p>
                <p><input type="text" name="mail" value=""> E-mail</p>
                <input type="hidden" name = "flPerson" value="true">
                <p><input type="submit" value="Add info"></p><br>
            </form>
<?php
        }
        else{
            $person->getPerson($firstName, $lastName);
            echo '<p><b>Person</b></p>';
            echo '<p>First name: ' . $person->values['firstName'] . '</p>';
            echo '<p>Last name: ' . $person->values['lastName'] . '</p>';
            echo '<p>Date of birth: ' . $person->values['dateOfBirth'] . '</p>';
            echo '<p>Address: ' . $person->values['address'] . '</p>';
            echo '<p>Phone: ' . $person->values['phone'] . '</p>';
            echo '<p>E-mail: ' . $person->values['mail'] . '</p><br>';

            echo "<p><a href='addAuto.php?idPerson=" . $person->values['idPerson'] .
                 "&firstName=" . $firstName . "&lastName=" . $lastName . "'>Add auto of person</a></p>";

            $auto = new Auto($base->connection);
            if($auto->existAuto($person->values['idPerson'])){
                echo "<p><a href='showAuto.php?idPerson=" . $person->values['idPerson'] .
                     "&firstName=" . $firstName . "&lastName=" . $lastName . "'>Show auto of person and orders of auto</a></p>";
                echo "<p><a href='updateAuto.php?idPerson=" . $person->values['idPerson'] .
                     "&firstName=" . $firstName . "&lastName=" . $lastName . "'>Update auto of person</a></p>";
                echo "<p><a href='deleteAuto.php?idPerson=" . $person->values['idPerson'] .
                     "&firstName=" . $firstName . "&lastName=" . $lastName . "'>Delete auto of person</a></p>";
            }
            echo "<br>";
        }
        echo "<hr><br>";
    }
}
?>

<form action="<?php $_SERVER["PHP_SELF"]?>" method="post">
    <p><b>Enter first and last name of person</b></p>
    <p><input type="text" name="firstName" value=""> First name</p>
    <p><input type="text" name="lastName" value=""> Last name</p>
    <p><input type="submit" value="Show info"></p>
</form>

</body>
</html>