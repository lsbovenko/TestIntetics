<html>
<head>
</head>
<body>

<?php
function __autoload($class){
    require_once ($class.'.class.php');
}

if($_SERVER["REQUEST_METHOD"] == "GET"){
    $idAuto = $_GET["idAuto"];
    $idPerson = $_GET["idPerson"];
    $firstName = $_GET["firstName"];
    $lastName = $_GET["lastName"];
}

$base = Base::getInstance();

$order = new Order($base->connection);

if($order->existOrder($idAuto)){
    $order->getAllOrder($idAuto);
    echo '<p><b>Order</b></p>';
    echo '<table border="1">';
    echo '<tr><td>Date</td><td>Order amount</td><td>Order status</td></tr>';
    foreach($order->values as $curOrder){
        echo '<tr><td> '. $curOrder["date"] . '</td>';
        echo '<td>' . $curOrder["orderAmount"] . '</td>';
        echo '<td>' . $curOrder["orderStatus"] . '</td></tr>';
    }
    echo '</table>';
}
else{
    echo "No order";
}
?>

<p></p><br><hr><br>
<form action="showAuto.php" method="post">
    <input type="hidden" name = "idAuto" value="<?=$idAuto?>">
    <input type="hidden" name = "idPerson" value="<?=$idPerson?>">
    <input type="hidden" name = "firstName" value="<?=$firstName?>">
    <input type="hidden" name = "lastName" value="<?=$lastName?>">
    <p><input type="submit" value="Back to auto"></p>
</form>

<form action="index.php" method="post">
    <input type="hidden" name = "firstName" value="<?=$firstName?>">
    <input type="hidden" name = "lastName" value="<?=$lastName?>">
    <p><input type="submit" value="Back to person"></p>
</form>

</body>
</html>