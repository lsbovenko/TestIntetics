<?php
class Base{
    const SERVER = 'localhost';
    const LOGIN = 'root';
    const PASSWORD = '';

    public $connection;
    private static $_instance;

    public static function getInstance(){
        if(!(self::$_instance instanceOf self)){
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    private function __construct(){
        $conn = @mysqli_connect(self::SERVER, self::LOGIN, self::PASSWORD) or die("Don't connect with MySql");
        $sqlBase = "CREATE DATABASE Service_station";
        mysqli_query($conn, $sqlBase);
        mysqli_close($conn);
        $this->connection = @mysqli_connect(self::SERVER, self::LOGIN, self::PASSWORD, 'Service_station') or die("Don't connect with Service_station");
    }

    public function createTables(){
        $sqlPersons = "SHOW TABLES LIKE 'Persons'";
        if((mysqli_query($this->connection, $sqlPersons)->num_rows) == 0){
            $sqlCPersons = "CREATE TABLE Persons (Id_person INT(4) AUTO_INCREMENT PRIMARY KEY,
                                                  First_name VARCHAR(20),
                                                  Last_name VARCHAR(20),
                                                  Date_of_birth VARCHAR(20),
                                                  Address VARCHAR(100),
                                                  Phone VARCHAR(20),
                                                  Mail VARCHAR(20))";
            mysqli_query($this->connection, $sqlCPersons);
        }
        $sqlAutos = "SHOW TABLES LIKE 'Autos'";
        if((mysqli_query($this->connection, $sqlAutos)->num_rows) == 0){
            $sqlCAutos = "CREATE TABLE Autos (Id_auto INT(4) AUTO_INCREMENT PRIMARY KEY,
                                              Id_person INT(4),
                                              Make VARCHAR(20),
                                              Model VARCHAR(20),
                                              Year VARCHAR(20),
                                              Vin VARCHAR(20))";
            mysqli_query($this->connection, $sqlCAutos);
        }
        $sqlOrders = "SHOW TABLES LIKE 'Orders'";
        if((mysqli_query($this->connection, $sqlOrders)->num_rows) == 0){
            $sqlCOrders = "CREATE TABLE Orders (Id_order INT(4) AUTO_INCREMENT PRIMARY KEY,
                                                Id_auto INT(4),
                                                Date DATETIME,
                                                Order_amount VARCHAR(20),
                                                Order_status VARCHAR(20))";
            mysqli_query($this->connection, $sqlCOrders);
        }
    }
}