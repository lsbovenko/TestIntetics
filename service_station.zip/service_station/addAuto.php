<?php
function __autoload($class){
    require_once ($class.'.class.php');
}

if($_SERVER["REQUEST_METHOD"] == "GET"){
    $idPerson = $_GET["idPerson"];
    $firstName = $_GET["firstName"];
    $lastName = $_GET["lastName"];
}
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $idPerson = $_POST["idPerson"];
    $firstName = $_POST["firstName"];
    $lastName = $_POST["lastName"];
    $make = trim(strip_tags($_POST["make"]));
    $model = trim(strip_tags($_POST["model"]));
    $year = trim(strip_tags($_POST["year"]));
    $vin = trim(strip_tags($_POST["vin"]));

    $base = Base::getInstance();

    $auto = new Auto($base->connection);
    $auto->setAuto($idPerson, $make, $model, $year, $vin);
}
?>

<html>
<head>
</head>
<body>

<form action="<?php $_SERVER["PHP_SELF"]?>" method="post">
    <p><b>Enter information of auto</b></p>
    <p><input type="text" name="make" value=""> Make</p>
    <p><input type="text" name="model" value=""> Model</p>
    <p><input type="text" name="year" value=""> Year</p>
    <p><input type="text" name="vin" value=""> Vin</p>
    <input type="hidden" name = "idPerson" value="<?=$idPerson?>">
    <input type="hidden" name = "firstName" value="<?=$firstName?>">
    <input type="hidden" name = "lastName" value="<?=$lastName?>">
    <p><input type="submit" value="Add info"></p>
</form>

<br><hr><br>
<form action="index.php" method="post">
    <input type="hidden" name = "firstName" value="<?=$firstName?>">
    <input type="hidden" name = "lastName" value="<?=$lastName?>">
    <p><input type="submit" value="Back to person"></p>
</form>

</body>
</html>