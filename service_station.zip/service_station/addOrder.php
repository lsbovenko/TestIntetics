<?php
function __autoload($class){
    require_once ($class.'.class.php');
}

if($_SERVER["REQUEST_METHOD"] == "GET"){
    $idAuto = $_GET["idAuto"];
    $idPerson = $_GET["idPerson"];
    $firstName = $_GET["firstName"];
    $lastName = $_GET["lastName"];
}
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $idAuto = $_POST["idAuto"];
    $idPerson = $_POST["idPerson"];
    $firstName = $_POST["firstName"];
    $lastName = $_POST["lastName"];
    $date = date("Y-m-d H:i:s", time());
    $orderAmount = trim(strip_tags($_POST["orderAmount"]));
    $orderStatus = $_POST["orderStatus"];

    $base = Base::getInstance();

    $order = new Order($base->connection);
    $order->setOrder($idAuto, $date, $orderAmount, $orderStatus);
}
?>

<html>
<head>
</head>
<body>

<form action="<?php $_SERVER["PHP_SELF"]?>" method="post">
    <p><b>Enter information of order</b></p>
    <p><input type="text" name="orderAmount" value=""> Order amount</p>

    <p>Select order status</p>
    <p><select size="1" name="orderStatus">
        <option value="Completed">Completed</option>
        <option value="In Progress">In Progress</option>
        <option value="Cancelled">Cancelled</option>
    </select></p>

    <input type="hidden" name = "idAuto" value="<?=$idAuto?>">
    <input type="hidden" name = "idPerson" value="<?=$idPerson?>">
    <input type="hidden" name = "firstName" value="<?=$firstName?>">
    <input type="hidden" name = "lastName" value="<?=$lastName?>">
    <p><input type="submit" value="Add info"></p>
</form>

<br><hr><br>
<form action="showAuto.php" method="post">
    <input type="hidden" name = "idAuto" value="<?=$idAuto?>">
    <input type="hidden" name = "idPerson" value="<?=$idPerson?>">
    <input type="hidden" name = "firstName" value="<?=$firstName?>">
    <input type="hidden" name = "lastName" value="<?=$lastName?>">
    <p><input type="submit" value="Back to auto"></p>
</form>

<form action="index.php" method="post">
    <input type="hidden" name = "firstName" value="<?=$firstName?>">
    <input type="hidden" name = "lastName" value="<?=$lastName?>">
    <p><input type="submit" value="Back to person"></p>
</form>

</body>
</html>