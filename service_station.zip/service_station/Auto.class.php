<?php
class Auto{
    public $connection;
    public $values;

    public function __construct($connection){
        $this->connection = $connection;
    }

    public function existAuto($idPerson){
        $sqlExist = "SELECT COUNT(*) FROM Autos WHERE Id_person = $idPerson";
        $resValues = mysqli_query($this->connection, $sqlExist);
        $item = mysqli_fetch_row($resValues);
        return $item[0];
    }

    public function setAuto($idPerson, $make, $model, $year, $vin){
        $sqlSet = "INSERT INTO Autos (Id_person, Make, Model, Year, Vin)
                   VALUES ($idPerson, '$make', '$model', '$year', '$vin')";
        mysqli_query($this->connection, $sqlSet);
    }

    public function getAuto($idAuto){
        $sqlGet = "SELECT * FROM Autos WHERE Id_auto = $idAuto";
        $resValues = mysqli_query($this->connection, $sqlGet);
        if($item = mysqli_fetch_assoc($resValues)){
            $curValues = array('idAuto'=>$item['Id_auto'],
                               'idPerson'=>$item['Id_person'],
                               'make'=>$item['Make'],
                               'model'=>$item['Model'],
                               'year'=>$item['Year'],
                               'vin'=>$item['Vin']);
        }
        return $curValues;
    }

    public function getAllAuto($idPerson){
        $sqlGetAll = "SELECT * FROM Autos WHERE Id_person = $idPerson";
        $resValues = mysqli_query($this->connection, $sqlGetAll);
        while($item = mysqli_fetch_assoc($resValues)){
            $this->values[] = array('idAuto'=>$item['Id_auto'],
                                    'idPerson'=>$item['Id_person'],
                                    'make'=>$item['Make'],
                                    'model'=>$item['Model'],
                                    'year'=>$item['Year'],
                                    'vin'=>$item['Vin']);
        }
    }

    public function updateAuto($idAuto, $make, $model, $year, $vin){
        $sqlUpdate = "UPDATE Autos SET Make = '$make', Model = '$model', Year = '$year', Vin = '$vin'
                      WHERE Id_auto = $idAuto";
        mysqli_query($this->connection, $sqlUpdate);
    }

    public function deleteAuto($idAuto){
        $sqlDelete = "DELETE FROM Autos WHERE Id_auto = $idAuto";
        mysqli_query($this->connection, $sqlDelete);
    }
}