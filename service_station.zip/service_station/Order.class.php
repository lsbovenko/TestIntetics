<?php
class Order{
    public $connection;
    public $values;

    public function __construct($connection){
        $this->connection = $connection;
    }

    public function existOrder($idAuto){
        $sqlExist = "SELECT COUNT(*) FROM Orders WHERE Id_auto = $idAuto";
        $resValues = mysqli_query($this->connection, $sqlExist);
        $item = mysqli_fetch_row($resValues);
        return $item[0];
    }

    public function setOrder($idAuto, $date, $orderAmount, $orderStatus){
        $sqlSet = "INSERT INTO Orders (Id_auto, Date, Order_amount, Order_status)
                   VALUES ($idAuto, '$date', '$orderAmount', '$orderStatus')";
        mysqli_query($this->connection, $sqlSet);
    }

    public function getOrder($idOrder){
        $sqlGet = "SELECT * FROM Orders WHERE Id_order = $idOrder";
        $resValues = mysqli_query($this->connection, $sqlGet);
        if($item = mysqli_fetch_assoc($resValues)){
            $curValues = array('idOrder'=>$item['Id_order'],
                               'idAuto'=>$item['Id_auto'],
                               'date'=>$item['Date'],
                               'orderAmount'=>$item['Order_amount'],
                               'orderStatus'=>$item['Order_status']);
        }
        return $curValues;
    }

    public function getAllOrder($idAuto){
        $sqlGetAll = "SELECT * FROM Orders WHERE Id_auto = $idAuto";
        $resValues = mysqli_query($this->connection, $sqlGetAll);
        while($item = mysqli_fetch_assoc($resValues)){
            $this->values[] = array('idOrder'=>$item['Id_order'],
                                    'idAuto'=>$item['Id_auto'],
                                    'date'=>$item['Date'],
                                    'orderAmount'=>$item['Order_amount'],
                                    'orderStatus'=>$item['Order_status']);
        }
    }

    public function updateOrder($idOrder, $orderAmount, $orderStatus){
        $sqlUpdate = "UPDATE Orders SET Order_amount = '$orderAmount', Order_status = '$orderStatus'
                      WHERE Id_order = $idOrder";
        mysqli_query($this->connection, $sqlUpdate);
    }

    public function deleteOrder($idOrder){
        $sqlDelete = "DELETE FROM Orders WHERE Id_order = $idOrder";
        mysqli_query($this->connection, $sqlDelete);
    }
}